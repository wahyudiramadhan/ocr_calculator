import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'blocs/expression_bloc/expression_bloc.dart';
import 'blocs/storage_bloc/storage_bloc.dart';
import 'screens/home_screen.dart';
import 'helpers/result_storage.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(
          create: (_) => ExpressionBloc(),
        ),
        BlocProvider(
          create: (_) => StorageBloc(ResultStorage()),
        ),
      ],
      child: MaterialApp(
        title: 'Image to Result Calculator',
        theme: ThemeData(
          primarySwatch: Colors.blue,
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        home: HomeScreen(),
      ),
    );
  }
}
