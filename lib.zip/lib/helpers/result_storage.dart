import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class ResultStorage {
  // Fungsi untuk menyimpan hasil ke file JSON
  Future<void> saveResultToFile(
      String rawText, String expression, String result) async {
    final directory = await getApplicationDocumentsDirectory();
    final file = File('${directory.path}/results.json');
    List<Map<String, dynamic>> fileData = [];

    // Jika file sudah ada, ambil datanya terlebih dahulu
    if (await file.exists()) {
      String content = await file.readAsString();
      fileData = List<Map<String, dynamic>>.from(json.decode(content));
    }

    // Tambahkan hasil baru
    fileData.add({
      'rawText': rawText,
      'expression': expression,
      'result': result,
    });

    // Simpan kembali ke file
    await file.writeAsString(json.encode(fileData));
  }

  // Fungsi untuk memuat hasil dari file JSON
  Future<List<Map<String, dynamic>>> loadResultsFromFile() async {
    final directory = await getApplicationDocumentsDirectory();
    final file = File('${directory.path}/results.json');

    if (await file.exists()) {
      String content = await file.readAsString();
      return List<Map<String, dynamic>>.from(json.decode(content));
    }

    return [];
  }

  // Fungsi untuk menyimpan hasil ke database SQLite
  Future<void> saveResultToDatabase(
      String rawText, String expression, String result) async {
    final db = await _getDatabase();
    await db.insert('Results', {
      'rawText': rawText,
      'expression': expression,
      'result': result,
    });
  }

  // Fungsi untuk memuat hasil dari database SQLite
  Future<List<Map<String, dynamic>>> loadResultsFromDatabase() async {
    final db = await _getDatabase();
    return await db.query('Results', orderBy: 'id DESC');
  }

  // Fungsi untuk mendapatkan database SQLite
  Future<Database> _getDatabase() async {
    return openDatabase(
      'results.db',
      version: 1,
      onCreate: (Database db, int version) async {
        await db.execute(
          'CREATE TABLE Results (id INTEGER PRIMARY KEY AUTOINCREMENT, rawText TEXT, expression TEXT, result TEXT)',
        );
      },
    );
  }

  // Fungsi umum untuk memuat hasil dari penyimpanan file dan database
  Future<List<Map<String, dynamic>>> loadResults() async {
    List<Map<String, dynamic>> combinedResults = [];

    // Muat hasil dari database
    List<Map<String, dynamic>> databaseResults =
        await loadResultsFromDatabase();
    combinedResults.addAll(databaseResults);

    // Muat hasil dari file
    List<Map<String, dynamic>> fileResults = await loadResultsFromFile();
    combinedResults.addAll(fileResults);

    return combinedResults;
  }
}
