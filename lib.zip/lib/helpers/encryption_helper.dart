import 'dart:typed_data';
import 'package:encrypt/encrypt.dart' as encrypt;
import 'dart:io';

class EncryptionHelper {
  final _key = encrypt.Key.fromUtf8(
      'my32lengthsupersecretnooneknows1'); // Kunci 32 karakter
  final _iv = encrypt.IV.fromLength(16);

  // Enkripsi teks
  String encryptText(String text) {
    final encrypter = encrypt.Encrypter(encrypt.AES(_key));
    final encrypted = encrypter.encrypt(text, iv: _iv);
    return encrypted.base64;
  }

  // Dekripsi teks
  String decryptText(String encryptedText) {
    final encrypter = encrypt.Encrypter(encrypt.AES(_key));
    return encrypter.decrypt64(encryptedText, iv: _iv);
  }

  // Enkripsi file (gambar)
  Future<String> encryptFile(File file) async {
    final bytes = await file.readAsBytes();
    final encryptedBytes = _encryptBytes(bytes);
    final encryptedFilePath = '${file.path}.enc';
    final encryptedFile = File(encryptedFilePath);
    await encryptedFile.writeAsBytes(encryptedBytes);
    return encryptedFilePath;
  }

  // Dekripsi file (gambar)
  Future<String> decryptFile(String encryptedFilePath) async {
    final encryptedFile = File(encryptedFilePath);
    final encryptedBytes = await encryptedFile.readAsBytes();
    final decryptedBytes = _decryptBytes(encryptedBytes);
    final decryptedFilePath = encryptedFilePath.replaceAll('.enc', '');
    final decryptedFile = File(decryptedFilePath);
    await decryptedFile.writeAsBytes(decryptedBytes);
    return decryptedFilePath;
  }

  // Enkripsi byte array (untuk file)
  List<int> _encryptBytes(Uint8List bytes) {
    final encrypter = encrypt.Encrypter(encrypt.AES(_key));
    return encrypter.encryptBytes(bytes, iv: _iv).bytes;
  }

  // Dekripsi byte array (untuk file)
  List<int> _decryptBytes(Uint8List encryptedBytes) {
    final encrypter = encrypt.Encrypter(encrypt.AES(_key));
    return encrypter.decryptBytes(encrypt.Encrypted(encryptedBytes), iv: _iv);
  }
}
