class TextRecognitionHelper {
  // Fungsi untuk mengekstrak ekspresi matematika dari teks
  String extractExpression(String text) {
    text = text.replaceAll('x', '*'); // Ganti tanda kali

    final RegExp exp = RegExp(r'(\d+)\s*([+\-*/])\s*(\d+)');
    final match = exp.firstMatch(text);

    if (match != null) {
      String num1 = match.group(1)!;
      String operator = match.group(2)!;
      String num2 = match.group(3)!;
      return '$num1$operator$num2';
    } else {
      throw 'Ekspresi tidak valid';
    }
  }

  // Fungsi untuk mengevaluasi ekspresi matematika
  double evaluateExpression(String expression) {
    try {
      final RegExp exp = RegExp(r'(\d+)([+\-*/])(\d+)');
      final match = exp.firstMatch(expression);

      if (match != null) {
        double num1 = double.parse(match.group(1)!);
        String operator = match.group(2)!;
        double num2 = double.parse(match.group(3)!);

        switch (operator) {
          case '+':
            return num1 + num2;
          case '-':
            return num1 - num2;
          case '*':
            return num1 * num2;
          case '/':
            return num1 / num2;
          default:
            throw 'Operator tidak valid';
        }
      } else {
        throw 'Ekspresi tidak valid';
      }
    } catch (e) {
      throw 'Gagal mengevaluasi ekspresi: $e';
    }
  }
}
