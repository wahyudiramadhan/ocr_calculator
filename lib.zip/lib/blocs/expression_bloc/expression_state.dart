import 'package:equatable/equatable.dart';

abstract class ExpressionState extends Equatable {
  @override
  List<Object> get props => [];
}

class ExpressionInitial extends ExpressionState {}

class ExpressionProcessing extends ExpressionState {}

class ExpressionSuccess extends ExpressionState {
  final String rawText;
  final String expression;
  final double result;

  ExpressionSuccess(this.rawText, this.expression, this.result);

  @override
  List<Object> get props => [rawText, expression, result];
}

class ExpressionFailure extends ExpressionState {
  final String error;

  ExpressionFailure(this.error);

  @override
  List<Object> get props => [error];
}
