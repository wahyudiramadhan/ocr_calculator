import 'package:equatable/equatable.dart';

abstract class ExpressionEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class ProcessExpression extends ExpressionEvent {
  final String rawText;

  ProcessExpression(this.rawText);

  @override
  List<Object> get props => [rawText];
}
