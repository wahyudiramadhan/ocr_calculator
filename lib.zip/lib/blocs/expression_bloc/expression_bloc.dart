import 'package:bloc/bloc.dart';
import 'expression_event.dart';
import 'expression_state.dart';
import '../../helpers/text_recognition_helper.dart';

class ExpressionBloc extends Bloc<ExpressionEvent, ExpressionState> {
  ExpressionBloc() : super(ExpressionInitial()) {
    on<ProcessExpression>(_onProcessExpression);
  }

  Future<void> _onProcessExpression(
      ProcessExpression event, Emitter<ExpressionState> emit) async {
    emit(ExpressionProcessing());

    try {
      // Proses ekspresi
      final expressionHelper = TextRecognitionHelper();
      final expression = expressionHelper.extractExpression(event.rawText);
      final result = expressionHelper.evaluateExpression(expression);

      emit(ExpressionSuccess(event.rawText, expression, result));
    } catch (error) {
      emit(ExpressionFailure('Gagal memproses ekspresi: $error'));
    }
  }
}
