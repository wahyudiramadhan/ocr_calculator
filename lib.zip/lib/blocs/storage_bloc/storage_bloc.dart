import 'package:bloc/bloc.dart';
import '../../helpers/result_storage.dart';
import 'storage_event.dart';
import 'storage_state.dart';

class StorageBloc extends Bloc<StorageEvent, StorageState> {
  final ResultStorage resultStorage;

  StorageBloc(this.resultStorage) : super(StorageInitial()) {
    on<SaveResultToFile>(_onSaveResultToFile);
    on<LoadResults>(_onLoadResults);
  }

  Future<void> _onSaveResultToFile(
      SaveResultToFile event, Emitter<StorageState> emit) async {
    emit(StorageLoading());
    try {
      await resultStorage.saveResultToFile(
          event.rawText, event.expression, event.result);
      add(LoadResults());
    } catch (error) {
      emit(StorageFailure('Gagal menyimpan hasil: $error'));
    }
  }

  Future<void> _onLoadResults(
      LoadResults event, Emitter<StorageState> emit) async {
    emit(StorageLoading());
    try {
      final results = await resultStorage.loadResults();
      emit(StorageSuccess(results));
    } catch (error) {
      emit(StorageFailure('Gagal memuat hasil: $error'));
    }
  }
}
