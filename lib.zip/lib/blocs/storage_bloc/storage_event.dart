import 'package:equatable/equatable.dart';

abstract class StorageEvent extends Equatable {
  @override
  List<Object> get props => [];
}

class SaveResultToFile extends StorageEvent {
  final String rawText;
  final String expression;
  final String result;

  SaveResultToFile(this.rawText, this.expression, this.result);

  @override
  List<Object> get props => [rawText, expression, result];
}

class LoadResults extends StorageEvent {}
