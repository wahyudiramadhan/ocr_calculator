import 'package:equatable/equatable.dart';

abstract class StorageState extends Equatable {
  @override
  List<Object> get props => [];
}

class StorageInitial extends StorageState {}

class StorageLoading extends StorageState {}

class StorageSuccess extends StorageState {
  final List<Map<String, dynamic>> results;

  StorageSuccess(this.results);

  @override
  List<Object> get props => [results];
}

class StorageFailure extends StorageState {
  final String error;

  StorageFailure(this.error);

  @override
  List<Object> get props => [error];
}
