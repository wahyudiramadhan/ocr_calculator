import 'dart:io';
import 'package:flutter/material.dart';

class DetailScreen extends StatelessWidget {
  final String rawData;
  final String expression;
  final String result;
  final String imagePath;

  DetailScreen({
    required this.rawData,
    required this.expression,
    required this.result,
    required this.imagePath,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Data'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            const Text('Raw Data:',
                style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(rawData),
            const SizedBox(height: 16),
            const Text('Perhitungan:',
                style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(expression), // Tampilkan ekspresi perhitungan
            const SizedBox(height: 16),
            const Text('Result:',
                style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(result),
            const SizedBox(height: 16),
            imagePath.isNotEmpty
                ? Column(
                    children: [
                      const Text('Gambar:',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      Image.file(
                        File(imagePath.replaceAll(
                            '.enc', '')), // Tampilkan gambar yang didekripsi
                        width: double.infinity,
                        fit: BoxFit.cover,
                      ),
                    ],
                  )
                : const SizedBox.shrink(),
          ],
        ),
      ),
    );
  }
}
