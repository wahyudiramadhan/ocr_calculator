import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../blocs/expression_bloc/expression_bloc.dart';
import '../blocs/expression_bloc/expression_state.dart';
import '../blocs/storage_bloc/storage_bloc.dart';
import '../blocs/storage_bloc/storage_event.dart';
import '../blocs/storage_bloc/storage_state.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Image to Result Calculator'),
      ),
      body: BlocListener<StorageBloc, StorageState>(
        listener: (context, state) {
          if (state is StorageFailure) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Error: ${state.error}')),
            );
          }
        },
        child: BlocBuilder<ExpressionBloc, ExpressionState>(
          builder: (context, state) {
            if (state is ExpressionInitial) {
              return const Center(child: Text('Pilih gambar untuk mulai.'));
            } else if (state is ExpressionProcessing) {
              return const Center(child: CircularProgressIndicator());
            } else if (state is ExpressionSuccess) {
              return Column(
                children: [
                  Text('Raw Data: ${state.rawText}'),
                  Text('Expression: ${state.expression}'),
                  Text('Result: ${state.result}'),
                  ElevatedButton(
                    onPressed: () {
                      BlocProvider.of<StorageBloc>(context).add(
                        SaveResultToFile(
                          state.rawText,
                          state.expression,
                          state.result.toString(),
                        ),
                      );
                    },
                    child: const Text('Simpan Hasil'),
                  ),
                ],
              );
            } else if (state is ExpressionFailure) {
              return Center(child: Text('Error: ${state.error}'));
            }
            return Container();
          },
        ),
      ),
    );
  }
}
